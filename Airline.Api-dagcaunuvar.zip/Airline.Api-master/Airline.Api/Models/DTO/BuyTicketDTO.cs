﻿namespace Airline.Api.Models.DTO
{
    public class BuyTicketDTO
    {
        public int FlightId { get; set; }
        public int userId { get; set; }
    }
}
